package com.example.christine_emerson_weight_tracker_app;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import com.example.christineemersonweighttrackingapp.R;

/**
 * The `MainActivity` class is a part of the FitTrack Android application project.
 * This class represents the main activity of the application, serving as the entry
 * point. It provides options for users to navigate to the login screen or sign up.
 * The class initializes a DatabaseHelper for the main database used in the application.
 * * Project: FitTrack Android Application
 * Author: Christine Emerson
 * License: No license (proprietary)
 */
public class MainActivity extends AppCompatActivity {

    /**
     * Called when the activity is starting. This is where most initialization
     * should go: calling `setContentView(int)` to inflate the activity's UI,
     * using `findViewById(int)` to programmatically interact with widgets in
     * the UI, and other initialization.
     *
     * @param savedInstanceState If the activity is being re-initialized after
     *                           previously being shut down, then this Bundle
     *                           contains the data it most recently supplied in
     *                           onSaveInstanceState(Bundle). Otherwise, it is
     *                           null.
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        TextView loginLink = findViewById(R.id.login_button);
        Button signUpButton = findViewById(R.id.signup_button);

        // Initialize DatabaseHelper for the main database
        // Added database helper here
        DatabaseHelper dbHelper = new DatabaseHelper(this, "UserDatabase.db");

        loginLink.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, LoginActivity.class);
            startActivity(intent);
        });

        signUpButton.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, SignUpActivity.class);
            startActivity(intent);
        });
    }
}
