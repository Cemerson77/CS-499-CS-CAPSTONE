package com.example.christine_emerson_weight_tracker_app;

/**
 * The `DatabaseContract` class is a part of the FitTrack Android application project.
 * Contract class defining the schema for the Users table in the weight tracker application's SQLite database.
 * Encapsulates the table name and column names to ensure consistency in database-related operations.
 * Project: FitTrack Android Application
 * Author: Christine Emerson
 * License: No license (proprietary)
 */

public final class DatabaseContract {
    private DatabaseContract() {}

    public static class UserEntry {
        public static final String TABLE_NAME = "Users"; // The name of the table in the database
        public static final String COLUMN_USERNAME = "username"; // The column name for the username
        public static final String COLUMN_PASSWORD = "password"; // The column name for the password
        public static final String COLUMN_PHONE_NUMBER = "phoneNumber"; // The column name for the phone number
    }
}
