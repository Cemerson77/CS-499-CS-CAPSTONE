package com.example.christine_emerson_weight_tracker_app;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.christineemersonweighttrackingapp.R;

import java.util.List;
import java.util.Locale;

/**
 * The `WeightEntryAdapter` class is a part of the FitTrack Android application project.
 * RecyclerView adapter for displaying a list of WeightEntry objects.
 * Each item in the list includes the date, weight, and buttons for edit and delete actions.
 *
 * Project: FitTrack Android Application
 * Author: Christine Emerson
 * License: No license (proprietary)
 */
public class WeightEntryAdapter extends RecyclerView.Adapter<WeightEntryAdapter.ViewHolder> {
    private final List<WeightEntry> weightEntries;
    private final OnItemClickListener listener;

    /**
     * Constructs a WeightEntryAdapter with the specified list of WeightEntry objects and item click listener.
     *
     * @param weightEntries The list of WeightEntry objects to display.
     * @param listener      The click listener for edit and delete actions.
     */
    public WeightEntryAdapter(List<WeightEntry> weightEntries, OnItemClickListener listener) {
        this.weightEntries = weightEntries;
        this.listener = listener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // Inflate the layout for a single item in the RecyclerView
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_weight_entry, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        // Bind data to the ViewHolder
        WeightEntry weightEntry = weightEntries.get(position);
        holder.textViewDate.setText(weightEntry.getDate());

        // Display the weight and unit (kg or lb) next to it
        String unit = weightEntry.isKgUnit() ? "lb" : "kg";
        String weightText = String.format(Locale.US, "%.2f %s", weightEntry.getWeight(), unit);
        holder.textViewWeight.setText(weightText);
    }

    @Override
    public int getItemCount() {
        return weightEntries.size();
    }

    /**
     * The ViewHolder class represents a single item view in the RecyclerView.
     */
    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView textViewDate;
        TextView textViewWeight;
        Button buttonEdit;
        Button buttonDelete;

        /**
         * Constructs a ViewHolder with the specified itemView.
         *
         * @param itemView The view for a single item in the RecyclerView.
         */
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            // Initialize views from the item layout
            textViewDate = itemView.findViewById(R.id.textViewDate);
            textViewWeight = itemView.findViewById(R.id.textViewWeight);
            buttonEdit = itemView.findViewById(R.id.buttonEdit);
            buttonDelete = itemView.findViewById(R.id.buttonDelete);

            // Set click listeners for edit and delete buttons
            buttonEdit.setOnClickListener(v -> {
                int position = getBindingAdapterPosition();
                if (position != RecyclerView.NO_POSITION) {
                    // Notify the listener about the edit click event
                    listener.onEditClick(position);
                }
            });

            buttonDelete.setOnClickListener(v -> {
                int position = getBindingAdapterPosition();
                if (position != RecyclerView.NO_POSITION) {
                    // Notify the listener about the delete click event
                    listener.onDeleteClick(position);
                }
            });
        }
    }

    /**
     * The OnItemClickListener interface defines methods for handling item click events.
     */
    public interface OnItemClickListener {
        void onEditClick(int position);
        void onDeleteClick(int position);
    }
}
