package com.example.christine_emerson_weight_tracker_app;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

/**
 * The `GoalWeightDatabaseHelper` class is a part of the FitTrack Android application project.
 * Helper class for managing the SQLite database used to store goal weight entries in the weight tracker application.
 * Defines methods for creating, upgrading, and performing database operations related to goal weight entries.
 * Project: FitTrack Android Application
 * Author: Christine Emerson
 * License: No license (proprietary)
 */
public class GoalWeightDatabaseHelper extends SQLiteOpenHelper {
    public static final String TABLE_NAME = "GoalWeightEntries";
    public static final String COLUMN_DATE = "date";
    public static final String COLUMN_WEIGHT = "weight";

    // Constructor
    public GoalWeightDatabaseHelper(Context context) {
        super(context, "GoalWeightDatabase.db", null, 1);
    }

    // Called when the database is created for the first time
    @Override
    public void onCreate(SQLiteDatabase db) {
        // Create the GoalWeightEntries table
        String createTableQuery = "CREATE TABLE " + TABLE_NAME + " (" +
                COLUMN_DATE + " TEXT PRIMARY KEY," +
                COLUMN_WEIGHT + " REAL)";
        db.execSQL(createTableQuery);
    }

    // Called when the database needs to be upgraded
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Drop the existing GoalWeightEntries table and recreate it
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(db);
    }

    // Adds a new goal weight entry to the database
    public long addGoalWeightEntry(String date, double weight) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_DATE, date);
        values.put(COLUMN_WEIGHT, weight);
        return db.insert(TABLE_NAME, null, values);
    }

    // Deletes a goal weight entry from the database based on the date
    public void deleteGoalWeightEntry(String date) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_NAME, COLUMN_DATE + " = ?", new String[]{date});
        db.close();
    }

    // Retrieves the most recent goal weight entry from the database
    public GoalWeightEntry getMostRecentGoalWeightEntry() {
        SQLiteDatabase db = getReadableDatabase();
        try (Cursor cursor = db.query(TABLE_NAME, null, null, null, null, null, COLUMN_DATE + " DESC", "1")) {
            GoalWeightEntry mostRecentEntry = null;
            if (cursor != null && cursor.moveToFirst()) {
                int dateIndex = cursor.getColumnIndex(COLUMN_DATE);
                int weightIndex = cursor.getColumnIndex(COLUMN_WEIGHT);

                // Check if the column indexes are valid (not -1)
                if (dateIndex != -1 && weightIndex != -1) {
                    String date = cursor.getString(dateIndex);
                    double weight = cursor.getDouble(weightIndex);
                    mostRecentEntry = new GoalWeightEntry(date, weight);
                }
            }
            return mostRecentEntry;
        }
    }

    // Retrieves all goal weight entries from the database
    public List<GoalWeightEntry> getAllGoalWeightEntries() {
        List<GoalWeightEntry> entries = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();
        try (Cursor cursor = db.query(TABLE_NAME, null, null, null, null, null, COLUMN_DATE)) {
            if (cursor != null && cursor.moveToFirst()) {
                int dateIndex = cursor.getColumnIndex(COLUMN_DATE);
                int weightIndex = cursor.getColumnIndex(COLUMN_WEIGHT);

                do {
                    // Check if the column indexes are valid (not -1)
                    if (dateIndex != -1 && weightIndex != -1) {
                        String date = cursor.getString(dateIndex);
                        double weight = cursor.getDouble(weightIndex);
                        GoalWeightEntry entry = new GoalWeightEntry(date, weight);
                        entries.add(entry);
                    }
                } while (cursor.moveToNext());
            }
        } finally {
            db.close();
        }
        return entries;
    }
}