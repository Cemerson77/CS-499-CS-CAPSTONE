package com.example.christine_emerson_weight_tracker_app;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/**
 * The `GoalWeightEntry` class is a part of the FitTrack Android application project.
 * Represents an entry in the goal weight database with properties for date and weight.
 * Provides methods to retrieve and manipulate these properties.
 *
 * Project: FitTrack Android Application
 * Author: Christine Emerson
 * License: No license (proprietary)
 */
public class GoalWeightEntry {
    private String date; // The date of the goal weight entry
    private double weight; // The weight value of the goal

    /**
     * Constructor for the GoalWeightEntry class.
     * Initializes the goal weight entry with the given date and weight.
     *
     * @param date   The date of the goal weight entry.
     * @param weight The weight value of the goal.
     */
    public GoalWeightEntry(String date, double weight) {
        this.date = date;
        this.weight = weight;
    }

    /**
     * Gets the date of the goal weight entry.
     *
     * @return The date of the goal weight entry.
     */
    public String getDate() {
        return date;
    }

    /**
     * Sets the date of the goal weight entry.
     *
     * @param date The new date value.
     */
    public void setDate(String date) {
        this.date = date;
    }

    /**
     * Gets the weight value of the goal weight entry.
     *
     * @return The weight value of the goal weight entry.
     */
    public double getWeight() {
        return weight;
    }

    /**
     * Sets the weight value of the goal weight entry.
     *
     * @param weight The new weight value.
     */
    public void setWeight(double weight) {
        this.weight = weight;
    }

    /**
     * Gets the goal weight value.
     *
     * @return The goal weight value.
     */
    public double getGoalWeight() {
        return weight;
    }

    /**
     * Gets the formatted date for display.
     *
     * @return The formatted date as a string, e.g., "MM/dd/yyyy".
     */
    public String getFormattedDate() {
        // Format the date for display, e.g., "MM/dd/yyyy"
        SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy", Locale.US);
        try {
            Date dateObj = new SimpleDateFormat("yyyy/MM/dd", Locale.US).parse(date);
            return dateFormat.format(dateObj);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return date; // Return the original date if formatting fails
    }
}
