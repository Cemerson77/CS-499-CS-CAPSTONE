package com.example.christine_emerson_weight_tracker_app;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import org.mindrot.jbcrypt.BCrypt;

/**
 * The `DatabaseHelper` class is a part of the FitTrack Android application project.
 * Helper class for managing the SQLite database used in the weight tracker application.
 * Provides methods for creating, upgrading, and interacting with the Users table.
 * Handles user authentication, user data storage, and phone number association.
 * Project: FitTrack Android Application
 * Author: Christine Emerson
 * License: No license (proprietary)
 */
public class DatabaseHelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "UserDatabase.db"; // Database name
    private static final int DATABASE_VERSION = 2;

    public static final String TABLE_NAME = "Users";
    public static final String COLUMN_USERNAME = "username";
    public static final String COLUMN_PASSWORD = "password";
    private static final String COLUMN_PHONE_NUMBER = "phoneNumber";

    private String databaseName;

    public DatabaseHelper(Context context, String dbName) {
        super(context, dbName, null, DATABASE_VERSION);
        this.databaseName = dbName; // Initialize the database name
    }


    @Override
    public void onCreate(SQLiteDatabase db) {
        // Create the Users table with columns for username, password, and phone number.
        String createTableQuery = "CREATE TABLE " + TABLE_NAME + " (" +
                COLUMN_USERNAME + " TEXT PRIMARY KEY," +
                COLUMN_PASSWORD + " TEXT, " +
                COLUMN_PHONE_NUMBER + " TEXT)";

        // Create an index on the username column for faster retrieval
        String createIndexQuery = "CREATE INDEX idx_username ON " + TABLE_NAME + " (" + COLUMN_USERNAME + ")";

        db.execSQL(createTableQuery);
        db.execSQL(createIndexQuery);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Drop the existing Users table and recreate it.
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(db);
    }

    /**
     * Adds or updates the phone number associated with a user in the Users table.
     *
     * @param username    The username of the user.
     * @param phoneNumber The phone number to be associated with the user.
     * @return The result of the database operation (-1 if unsuccessful).
     */
    public long addUserPhoneNumber(String username, String phoneNumber) {
        long result = -1;
        SQLiteDatabase db = this.getWritableDatabase();
        db.beginTransaction();

        if (db != null) {
            try {
                ContentValues values = new ContentValues();
                values.put(COLUMN_USERNAME, username);
                values.put(COLUMN_PHONE_NUMBER, phoneNumber);

                // Use a prepared statement for the update operation
                String whereClause = COLUMN_USERNAME + " = ?";
                String[] whereArgs = {username};

                int rowsAffected = db.update(TABLE_NAME, values, whereClause, whereArgs);

                if (rowsAffected > 0) {
                    result = rowsAffected;
                } else {
                    result = db.insert(TABLE_NAME, null, values);
                }

                db.setTransactionSuccessful();
            } catch (SQLException e) {
                e.printStackTrace();
            } finally {
                db.endTransaction();
            }
        }

        return result;
    }

    /**
     * Retrieves the phone number associated with a user from the Users table.
     *
     * @param username The username of the user.
     * @return The phone number associated with the user.
     */
    public String getUserPhoneNumber(String username) {
        SQLiteDatabase db = this.getReadableDatabase();
        String phoneNumber = null;

        try {
            String[] columns = {COLUMN_PHONE_NUMBER};
            String selection = COLUMN_USERNAME + " = ?";
            String[] selectionArgs = {username};

            try (Cursor cursor = db.query(
                    TABLE_NAME,
                    columns,
                    selection,
                    selectionArgs,
                    null,
                    null,
                    null
            )) {
                if (cursor != null && cursor.moveToFirst()) {
                    int phoneNumberIndex = cursor.getColumnIndex(COLUMN_PHONE_NUMBER);
                    phoneNumber = cursor.getString(phoneNumberIndex);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return phoneNumber;
    }

    /**
     * Adds a new user to the Users table with the provided username and password.
     *
     * @param username The username of the new user.
     * @param password The password of the new user (hashed using BCrypt).
     * @return The result of the database operation (-1 if unsuccessful).
     */
    public long addUser(String username, String password) {
        long result = -1;
        SQLiteDatabase db = this.getWritableDatabase();
        db.beginTransaction();

        if (db != null) {
            try {
                ContentValues values = new ContentValues();
                values.put(COLUMN_USERNAME, username);
                values.put(COLUMN_PASSWORD, password);

                result = db.insert(TABLE_NAME, null, values);
                db.setTransactionSuccessful();
            } catch (SQLException e) {
                e.printStackTrace();
            } finally {
                db.endTransaction();
            }
        }

        return result;
    }

    /**
     * Checks if a username is already taken by querying the Users table.
     *
     * @param username The username to check for availability.
     * @return True if the username is taken, false otherwise.
     */
    public boolean isUsernameTaken(String username) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = null;

        try {
            String[] columns = {COLUMN_USERNAME};
            String selection = COLUMN_USERNAME + " = ?";
            String[] selectionArgs = {username};

            cursor = db.query(
                    TABLE_NAME,
                    columns,
                    selection,
                    selectionArgs,
                    null,
                    null,
                    null
            );

            return cursor != null && cursor.getCount() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        } finally {
            if (cursor != null) {
                cursor.close();
            }
        }
    }

    /**
     * Validates a user by checking the provided username and password against the Users table.
     *
     * @param username The username of the user to validate.
     * @param password The password to validate (hashed using BCrypt).
     * @return True if the user is valid, false otherwise.
     */
    public boolean isValidUser(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = null;

        try {
            String[] columns = {COLUMN_USERNAME, COLUMN_PASSWORD};
            String selection = COLUMN_USERNAME + " = ?";
            String[] selectionArgs = {username};

            cursor = db.query(
                    TABLE_NAME,
                    columns,
                    selection,
                    selectionArgs,
                    null,
                    null,
                    null
            );

            if (cursor != null && cursor.moveToFirst()) {
                int passwordIndex = cursor.getColumnIndex(COLUMN_PASSWORD);
                String hashedPassword = cursor.getString(passwordIndex);

                return BCrypt.checkpw(password, hashedPassword);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            if (cursor != null) {
                cursor.close();
            }
        }

        return false;
    }
}