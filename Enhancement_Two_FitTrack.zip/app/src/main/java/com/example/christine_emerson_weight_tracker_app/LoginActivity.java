package com.example.christine_emerson_weight_tracker_app;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.christineemersonweighttrackingapp.R;

/**
 * The `LoginActivity` class is a part of the FitTrack Android application project.
 * This class represents the login screen activity, allowing users to enter their
 * email and password for authentication. It checks for stored credentials, handles
 * input validation, and provides options for signing in, redirecting to sign up, and
 * remembering login credentials. The class interacts with a DatabaseHelper for user
 * authentication.
 * Project: FitTrack Android Application
 * Author: Christine Emerson
 * License: No license (proprietary)
 */
public class LoginActivity extends AppCompatActivity {
    private EditText emailEditText; // Input field for the user's email
    private EditText passwordEditText; // Input field for the user's password
    private DatabaseHelper dbHelper; // Helper class for database operations
    private CheckBox rememberMeCheckBox; // Checkbox for remembering login credentials

    /**
     * Called when the activity is starting. This is where most initialization
     * should go: calling `setContentView(int)` to inflate the activity's UI,
     * using `findViewById(int)` to programmatically interact with widgets in
     * the UI, and other initialization.
     *
     * @param savedInstanceState If the activity is being re-initialized after
     *                           previously being shut down, then this Bundle
     *                           contains the data it most recently supplied in
     *                           onSaveInstanceState(Bundle). Otherwise, it is
     *                           null.
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        emailEditText = findViewById(R.id.username);
        passwordEditText = findViewById(R.id.login_password);
        Button signInButton = findViewById(R.id.login_button);
        TextView signupRedirectText = findViewById(R.id.signupRedirectText);
        rememberMeCheckBox = findViewById(R.id.chkSaveCredentials);

        dbHelper = new DatabaseHelper(this, "UserDatabase.db");

        // Check for stored credentials and update UI
        checkAndLoadStoredCredentials();

        signInButton.setEnabled(true);

        emailEditText.addTextChangedListener(new TextWatcher());
        passwordEditText.addTextChangedListener(new TextWatcher());

        signInButton.setOnClickListener(v -> {
            String email = emailEditText.getText().toString();
            String password = passwordEditText.getText().toString();

            if (TextUtils.isEmpty(email) || TextUtils.isEmpty(password)) {
                showError("Email and password are required");
            } else {
                if (isValidUser(email, password)) {
                    Intent intent = new Intent(LoginActivity.this, WelcomeActivity.class);
                    startActivity(intent);
                    finish(); // Optional: Close the LoginActivity to prevent going back
                } else {
                    showError("Invalid username or password");
                }
            }
        });

        signupRedirectText.setOnClickListener(v -> {
            Intent intent = new Intent(LoginActivity.this, SignUpActivity.class);
            startActivity(intent);
        });
    }

    /**
     * Validates the user's credentials using the DatabaseHelper.
     *
     * @param email    The user's email.
     * @param password The user's password.
     * @return True if the credentials are valid, false otherwise.
     */
    private boolean isValidUser(String email, String password) {
        return dbHelper.isValidUser(email, password);
    }

    /**
     * Displays an error message using a Toast.
     *
     * @param errorMessage The error message to display.
     */
    private void showError(String errorMessage) {
        Toast.makeText(this, errorMessage, Toast.LENGTH_SHORT).show();
    }

    /**
     * Load stored credentials (if "Remember Me" is checked).
     */
    private void checkAndLoadStoredCredentials() {
        SharedPreferences preferences = getSharedPreferences("login_prefs", MODE_PRIVATE);
        boolean rememberMe = preferences.getBoolean("rememberMe", false);
        if (rememberMe) {
            String storedEmail = preferences.getString("email", "");
            String storedPassword = preferences.getString("password", "");
            emailEditText.setText(storedEmail);
            passwordEditText.setText(storedPassword);
            rememberMeCheckBox.setChecked(true);
        }
    }

    /**
     * Save credentials if "Remember Me" is checked.
     */
    private void saveCredentialsIfChecked() {
        if (rememberMeCheckBox.isChecked()) {
            String email = emailEditText.getText().toString();
            String password = passwordEditText.getText().toString();

            SharedPreferences preferences = getSharedPreferences("login_prefs", MODE_PRIVATE);
            SharedPreferences.Editor editor = preferences.edit();
            editor.putBoolean("rememberMe", true);
            editor.putString("email", email);
            editor.putString("password", password);
            editor.apply();
        }
    }

    /**
     * Custom TextWatcher class to enable/disable the sign-in button based on
     * input changes in email and password fields.
     */
    private class TextWatcher implements android.text.TextWatcher {
        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {
        }

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {
            boolean isEmailEmpty = TextUtils.isEmpty(emailEditText.getText().toString());
            boolean isPasswordEmpty = TextUtils.isEmpty(passwordEditText.getText().toString());

            Button signInButton = findViewById(R.id.login_button);
            signInButton.setEnabled(!isEmailEmpty && !isPasswordEmpty);
        }

        @Override
        public void afterTextChanged(android.text.Editable s) {
        }
    }

    /**
     * Called when the activity is no longer visible to the user, saves credentials.
     */
    @Override
    protected void onStop() {
        super.onStop();
        saveCredentialsIfChecked();
    }
}
