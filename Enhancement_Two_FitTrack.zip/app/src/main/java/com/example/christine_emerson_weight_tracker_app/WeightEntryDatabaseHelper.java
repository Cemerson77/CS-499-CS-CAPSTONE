package com.example.christine_emerson_weight_tracker_app;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.util.ArrayList;
import java.util.List;

/**
 * The `WeightEntryDatabaseHelper` class is a part of the FitTrack Android application project.
 * SQLiteOpenHelper subclass for managing the WeightEntries database.
 * Provides methods for creating the database, adding, updating, and deleting weight entries,
 * and retrieving all weight entries from the database
 * Project: FitTrack Android Application
 * Author: Christine Emerson
 * License: No license (proprietary)
 */
public class WeightEntryDatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "WeightEntries.db";
    private static final int DATABASE_VERSION = 1;

    // Table name and columns
    private static final String TABLE_NAME = "WeightEntries";
    private static final String COLUMN_ID = "id";
    private static final String COLUMN_DATE = "date";
    private static final String COLUMN_WEIGHT = "weight";
    private static final String COLUMN_IS_KG = "isKgUnit";

    // Constructor
    public WeightEntryDatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Create the WeightEntries table
        String createTableSQL = "CREATE TABLE " + TABLE_NAME + " (" +
                COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COLUMN_DATE + " TEXT, " +
                COLUMN_WEIGHT + " REAL, " +
                COLUMN_IS_KG + " INTEGER);";

        db.execSQL(createTableSQL);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Drop the existing table and recreate it on database upgrade
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(db);
    }

    // Add a new weight entry to the database
    public long addWeightEntry(WeightEntry weightEntry) {
        SQLiteDatabase db = getWritableDatabase(); // Open a writable database
        ContentValues values = new ContentValues();

        values.put(COLUMN_DATE, weightEntry.getDate());
        values.put(COLUMN_WEIGHT, weightEntry.getWeight());
        values.put(COLUMN_IS_KG, weightEntry.isKgUnit() ? 1 : 0);

        // Return the result of the insert operation
        return db.insert(TABLE_NAME, null, values);
    }

    // Update an existing weight entry in the database
    public void updateWeightEntry(WeightEntry updatedEntry) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put(COLUMN_WEIGHT, updatedEntry.getWeight());
        values.put(COLUMN_IS_KG, updatedEntry.isKgUnit() ? 1 : 0);

        // Return the result of the update operation directly
        db.update(TABLE_NAME, values, COLUMN_DATE + " = ?", new String[]{updatedEntry.getDate()});
    }

    // Delete a weight entry from the database using date
    public int deleteWeightEntry(String date) {
        SQLiteDatabase db = getWritableDatabase();
        // Return the result of the delete operation directly
        return db.delete(TABLE_NAME, COLUMN_DATE + " = ?", new String[]{date});
    }

    // Check if an entry with the given date already exists in the database
    public boolean doesEntryExistForDate(String date) {
        SQLiteDatabase db = getReadableDatabase();
        String query = "SELECT * FROM " + TABLE_NAME + " WHERE " + COLUMN_DATE + " = ?";
        // Execute the query and check if any result exists
        Cursor cursor = db.rawQuery(query, new String[]{date});
        boolean entryExists = cursor.getCount() > 0;
        cursor.close();
        return entryExists;
    }

    // Get all weight entries from the database
    public List<WeightEntry> getAllWeightEntries() {
        List<WeightEntry> weightEntries = new ArrayList<>();
        String selectQuery = "SELECT * FROM " + TABLE_NAME;

        SQLiteDatabase db = getWritableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);

        if (cursor.moveToFirst()) {
            do {
                @SuppressLint("Range") String date = cursor.getString(cursor.getColumnIndex(COLUMN_DATE));
                @SuppressLint("Range") double weight = cursor.getDouble(cursor.getColumnIndex(COLUMN_WEIGHT));
                @SuppressLint("Range") int isKgUnit = cursor.getInt(cursor.getColumnIndex(COLUMN_IS_KG));

                boolean isKg = isKgUnit == 1;
                WeightEntry entry = new WeightEntry(date, weight, isKg);
                weightEntries.add(entry);
            } while (cursor.moveToNext());
        }

        cursor.close();

        Log.d("SortDebug", "Before sorting: " + weightEntries);

        // Use Quick Sort to sort the list of weight entries
        WeightEntrySorter.quickSort(weightEntries);

        Log.d("SortDebug", "After sorting: " + weightEntries);

        return weightEntries;
    }

    // Nested class for Quick Sort algorithm
    private static class WeightEntrySorter {

        public static void quickSort(List<WeightEntry> weightEntries) {
            if (weightEntries == null || weightEntries.size() <= 1) {
                return; // Already sorted
            }

            Log.d("SortDebug", "Before sorting: " + weightEntries);
            quickSort(weightEntries, 0, weightEntries.size() - 1);
            Log.d("SortDebug", "After sorting: " + weightEntries);
        }

        private static void quickSort(List<WeightEntry> weightEntries, int low, int high) {
            if (low < high) {
                int pivotIndex = partition(weightEntries, low, high);
                quickSort(weightEntries, low, pivotIndex - 1);
                quickSort(weightEntries, pivotIndex + 1, high);
            }
        }

        private static int partition(List<WeightEntry> weightEntries, int low, int high) {
            String pivotDate = weightEntries.get(high).getDate();
            int i = low - 1;
            for (int j = low; j < high; j++) {
                if (compareDates(weightEntries.get(j).getDate(), pivotDate) < 0) {
                    i++;
                    swap(weightEntries, i, j);
                }
            }
            swap(weightEntries, i + 1, high);
            return i + 1;
        }

        private static void swap(List<WeightEntry> weightEntries, int i, int j) {
            WeightEntry temp = weightEntries.get(i);
            weightEntries.set(i, weightEntries.get(j));
            weightEntries.set(j, temp);
        }
        // Comparison of dates for sorting weight entries in ascending order
        private static int compareDates(String date1, String date2) {
            String[] parts1 = date1.split("-");
            String[] parts2 = date2.split("-");

            // Compare years
            int year1 = Integer.parseInt(parts1[0]);
            int year2 = Integer.parseInt(parts2[0]);
            if (year1 != year2) {
                return Integer.compare(year1, year2); // Compare in ascending order
            }

            // Compare months
            int month1 = Integer.parseInt(parts1[1]);
            int month2 = Integer.parseInt(parts2[1]);
            if (month1 != month2) {
                return Integer.compare(month1, month2); // Compare in ascending order
            }

            // Compare days
            int day1 = Integer.parseInt(parts1[2]);
            int day2 = Integer.parseInt(parts2[2]);
            return Integer.compare(day1, day2); // Compare in ascending order
        }
    }
}
