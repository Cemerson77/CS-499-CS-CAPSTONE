package com.example.christine_emerson_weight_tracker_app;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;

import com.example.christineemersonweighttrackingapp.R;
import com.google.android.material.switchmaterial.SwitchMaterial;

/**
 * The `SettingsActivity` class is a part of the FitTrack Android application project.
 * This class represents the settings screen activity, allowing users to customize
 * app settings such as dark mode preference. User choices are persisted using
 * SharedPreferences, and changes are applied immediately. The activity also provides
 * a navigation option to return to the WelcomeActivity.
 * Project: FitTrack Android Application
 * Author: Christine Emerson
 * License: No license (proprietary)
 */
public class SettingsActivity extends AppCompatActivity {

    // SharedPreferences keys
    private static final String PREF_NAME = "MyAppPrefs";
    private static final String KEY_DARK_MODE = "darkMode";

    /**
     * Called when the activity is starting. This is where most initialization
     * should go: calling `setContentView(int)` to inflate the activity's UI,
     * using `findViewById(int)` to programmatically interact with widgets in
     * the UI, and other initialization.
     *
     * @param savedInstanceState If the activity is being re-initialized after
     *                           previously being shut down, then this Bundle
     *                           contains the data it most recently supplied in
     *                           onSaveInstanceState(Bundle). Otherwise, it is
     *                           null.
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        // Find the dark mode switch in the layout
        SwitchMaterial darkModeSwitch = findViewById(R.id.darkModeSwitch);

        // Load user's preference for dark mode from SharedPreferences
        boolean isDarkMode = loadDarkModePreference();

        // Set the initial state of the dark mode switch
        darkModeSwitch.setChecked(isDarkMode);

        // Set a listener for changes in the dark mode switch
        darkModeSwitch.setOnCheckedChangeListener((buttonView, isChecked) -> {
            // Save user's preference for dark mode to SharedPreferences
            saveDarkModePreference(isChecked);

            // Apply dark mode immediately
            if (isChecked) {
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);
            } else {
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
            }

            // Recreate the activity to apply the new theme
            recreate();
        });

        // Find the home button view
        ImageButton backButton = findViewById(R.id.homeButton);

        // Set a click listener for the home button
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Navigate back to the WelcomeActivity
                Intent intent = new Intent(SettingsActivity.this, WelcomeActivity.class);
                startActivity(intent);
                finish(); // Close the current activity
            }
        });
    }

    /**
     * Save the user's dark mode preference to SharedPreferences.
     *
     * @param isDarkMode True if dark mode is enabled, false otherwise.
     */
    private void saveDarkModePreference(boolean isDarkMode) {
        // Get SharedPreferences instance
        SharedPreferences sharedPreferences = getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);

        // Get SharedPreferences editor
        SharedPreferences.Editor editor = sharedPreferences.edit();

        // Save the dark mode preference
        editor.putBoolean(KEY_DARK_MODE, isDarkMode);

        // Apply changes
        editor.apply();
    }

    /**
     * Load the user's dark mode preference from SharedPreferences.
     *
     * @return True if dark mode is enabled, false otherwise.
     */
    private boolean loadDarkModePreference() {
        // Get SharedPreferences instance
        SharedPreferences sharedPreferences = getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);

        // Load the dark mode preference, default to false
        return sharedPreferences.getBoolean(KEY_DARK_MODE, false);
    }
}
