package com.example.christine_emerson_weight_tracker_app;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.example.christineemersonweighttrackingapp.R;

import java.util.List;

/**
 * The `GoalWeightEntryAdapter` class is a part of the FitTrack Android application project.
 * This class serves as an adapter for displaying a list of GoalWeightEntry objects
 * in a customized format within a ListView or GridView. It inflates the layout for
 * each item and sets the corresponding data (date and weight) from the GoalWeightEntry
 * objects.
 * Project: FitTrack Android Application
 * Author: Christine Emerson
 * License: No license (proprietary)
 */
public class GoalWeightEntryAdapter extends BaseAdapter {
    private Context context; // The context in which the adapter operates
    private List<GoalWeightEntry> goalWeightEntries; // The list of goal weight entries to display

    /**
     * Constructor for the GoalWeightEntryAdapter class.
     *
     * @param context           The context in which the adapter operates.
     * @param goalWeightEntries The list of goal weight entries to display.
     */
    public GoalWeightEntryAdapter(Context context, List<GoalWeightEntry> goalWeightEntries) {
        this.context = context;
        this.goalWeightEntries = goalWeightEntries;
    }

    /**
     * Gets the number of items in the adapter.
     *
     * @return The number of goal weight entries in the list.
     */
    @Override
    public int getCount() {
        return goalWeightEntries.size();
    }

    /**
     * Gets the item at the specified position.
     *
     * @param position The position of the item in the adapter.
     * @return The GoalWeightEntry at the specified position.
     */
    @Override
    public Object getItem(int position) {
        return goalWeightEntries.get(position);
    }

    /**
     * Gets the ID of the item at the specified position.
     *
     * @param position The position of the item in the adapter.
     * @return The ID of the item at the specified position.
     */
    @Override
    public long getItemId(int position) {
        return position;
    }

    /**
     * Gets a View that displays the data at the specified position in the adapter.
     *
     * @param position    The position of the item within the adapter's data set.
     * @param convertView The old view to reuse, if possible.
     * @param parent      The parent view that this view will eventually be attached to.
     * @return A View corresponding to the data at the specified position.
     */
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            convertView = LayoutInflater.from(context).inflate(R.layout.item_goal_weight_entry, parent, false);
        }

        // Get the current goal weight entry
        GoalWeightEntry goalWeightEntry = goalWeightEntries.get(position);

        // Initialize TextViews in the item layout
        TextView dateTextView = convertView.findViewById(R.id.dateTextView);
        TextView weightTextView = convertView.findViewById(R.id.weightTextView);

        // Set the text for date and weight
        dateTextView.setText(goalWeightEntry.getFormattedDate());
        weightTextView.setText(String.valueOf(goalWeightEntry.getWeight()));

        return convertView;
    }
}
