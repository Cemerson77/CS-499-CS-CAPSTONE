package com.example.christine_emerson_weight_tracker_app;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

/**
 * The `GoalWeightDatabaseHelper` class is a part of the FitTrack Android application project.
 * Helper class for managing the SQLite database used to store goal weight entries in the weight tracker application.
 * Defines methods for creating, upgrading, and performing database operations related to goal weight entries.
 * Project: FitTrack Android Application
 * Author: Christine Emerson
 * License: No license (proprietary)
 */
public class GoalWeightDatabaseHelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "GoalWeightDatabase.db";
    private static final int DATABASE_VERSION = 1;
    public static final String TABLE_NAME = "GoalWeightEntries";
    public static final String COLUMN_DATE = "date";
    public static final String COLUMN_WEIGHT = "weight";

    /**
     * Constructor for the GoalWeightDatabaseHelper class.
     * Initializes the database helper with the given context.
     *
     * @param context The application context.
     */
    public GoalWeightDatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    /**
     * Called when the database is created for the first time.
     * Creates the goal weight entries table.
     *
     * @param db The SQLite database.
     */
    @Override
    public void onCreate(SQLiteDatabase db) {
        String createTableQuery = "CREATE TABLE " + TABLE_NAME + " (" +
                COLUMN_DATE + " TEXT PRIMARY KEY," +
                COLUMN_WEIGHT + " REAL)";
        db.execSQL(createTableQuery);
    }

    /**
     * Called when the database needs to be upgraded.
     * Drops the existing table and creates a new one.
     *
     * @param db         The SQLite database.
     * @param oldVersion The old database version.
     * @param newVersion The new database version.
     */
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(db);
    }

    /**
     * Adds a new goal weight entry to the database.
     *
     * @param date   The date of the goal weight entry.
     * @param weight The weight value of the goal.
     * @return The row ID of the newly inserted row, or -1 if an error occurred.
     */
    public long addGoalWeightEntry(String date, double weight) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_DATE, date);
        values.put(COLUMN_WEIGHT, weight);
        return db.insert(TABLE_NAME, null, values);
    }

    /**
     * Deletes a goal weight entry from the database based on the date.
     *
     * @param date The date of the goal weight entry to be deleted.
     */
    public void deleteGoalWeightEntry(String date) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_NAME, COLUMN_DATE + " = ?", new String[]{date});
        db.close();
    }

    /**
     * Retrieves the most recent goal weight entry from the database.
     *
     * @return The most recent goal weight entry, or null if no entry exists.
     */
    public GoalWeightEntry getMostRecentGoalWeightEntry() {
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = db.query(TABLE_NAME, null, null, null, null, null, COLUMN_DATE + " DESC", "1");
        GoalWeightEntry mostRecentEntry = null;
        if (cursor != null && cursor.moveToFirst()) {
            @SuppressLint("Range") String date = cursor.getString(cursor.getColumnIndex(COLUMN_DATE));
            @SuppressLint("Range") double weight = cursor.getDouble(cursor.getColumnIndex(COLUMN_WEIGHT));
            mostRecentEntry = new GoalWeightEntry(date, weight);
            cursor.close();
        }
        return mostRecentEntry;
    }

    /**
     * Retrieves all goal weight entries from the database.
     *
     * @return A list of all goal weight entries in the database.
     */
    public List<GoalWeightEntry> getAllGoalWeightEntries() {
        List<GoalWeightEntry> entries = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = db.query(TABLE_NAME, null, null, null, null, null, null);
        if (cursor != null && cursor.moveToFirst()) {
            do {
                @SuppressLint("Range") String date = cursor.getString(cursor.getColumnIndex(COLUMN_DATE));
                @SuppressLint("Range") double weight = cursor.getDouble(cursor.getColumnIndex(COLUMN_WEIGHT));
                GoalWeightEntry entry = new GoalWeightEntry(date, weight);
                entries.add(entry);
            } while (cursor.moveToNext());
            cursor.close();
        }
        return entries;
    }
}
