package com.example.christine_emerson_weight_tracker_app;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;

import androidx.appcompat.app.AppCompatActivity;

import com.example.christineemersonweighttrackingapp.R;

/**
 * The `SplashActivity` class is a part of the FitTrack Android application project.
 * This activity displays a splash screen for a specified duration and then navigates to the main activity.
 * It serves as the initial screen when the weight tracker app is launched.
 *
 * Features:
 * - Displays a splash screen for a specified duration (3 seconds by default).
 * - Navigates to the main activity after the splash screen.
 *
 * Notes:
 * - The splash screen duration is set to 3 seconds (adjustable via SPLASH_DISPLAY_LENGTH).
 * - This class initializes the DatabaseHelper for the sign-up database.
 *
 * Project: FitTrack Android Application
 * Author: Christine Emerson
 * License: No license (proprietary)
 */
public class SplashActivity extends AppCompatActivity {

    // Duration of the splash screen in milliseconds (3 seconds by default)
    private static final long SPLASH_DISPLAY_LENGTH = 3000;

    // Database helper for sign-up database
    private DatabaseHelper dbHelper;

    /**
     * Called when the activity is starting. This is where most initialization
     * should go: calling `setContentView(int)` to inflate the activity's UI,
     * using `findViewById(int)` to programmatically interact with widgets in
     * the UI, and other initialization.
     *
     * @param savedInstanceState If the activity is being re-initialized after
     *                           previously being shut down, then this Bundle
     *                           contains the data it most recently supplied in
     *                           onSaveInstanceState(Bundle). Otherwise, it is
     *                           null.
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        // Initialize DatabaseHelper for the sign-up database
        dbHelper = new DatabaseHelper(this, "UserDatabase.db");

        // Use a Handler to post a delayed action to navigate to the main activity
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                // Create an Intent to navigate to the main activity
                Intent mainIntent = new Intent(SplashActivity.this, MainActivity.class);
                startActivity(mainIntent);
                finish();
            }
        }, SPLASH_DISPLAY_LENGTH);
    }
}
