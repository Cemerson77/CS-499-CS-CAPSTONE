
package com.example.christine_emerson_weight_tracker_app;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.text.InputType;
import android.text.TextUtils;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import androidx.core.content.ContextCompat;

import com.example.christineemersonweighttrackingapp.R;

import org.mindrot.jbcrypt.BCrypt;

import java.util.regex.Pattern;

/**
 * The `SignUpActivity` class is a part of the FitTrack Android application project.
 * This activity handles user registration, password strength validation, phone number validation,
 * and related functionalities in the weight tracker app.
 *
 * Features:
 * - User input validation for name, username, password, and phone number.
 * - Password strength check.
 * - Handling SMS and custom permissions.
 * - Sending a welcome notification.
 * - Saving user details in the database.
 * - Requesting and saving the user's phone number.
 * - Navigating to the login screen.
 *
 * Notes:
 * - This class uses the BCrypt library for password hashing.
 * - Permissions: SEND_SMS, custom permission for posting notifications.
 *
 * Project: FitTrack Android Application
 * Author: Christine Emerson
 * License: No license (proprietary)
 */

public class SignUpActivity extends AppCompatActivity {
    private EditText nameField;
    private EditText usernameField;
    private EditText passwordField;
    private EditText phoneNumberField;
    private DatabaseHelper dbHelper;

    private static final int SMS_PERMISSION_CODE = 101;
    private static final int CUSTOM_PERMISSION_CODE = 103;

    private static final String CHANNEL_ID = "MyChannel";
    private static final int NOTIFICATION_ID = 1;
    private static final String PREF_KEY_FIRST_LOGIN = "first_login";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);

        // Initialize UI elements
        nameField = findViewById(R.id.signup_name);
        usernameField = findViewById(R.id.signup_username);
        passwordField = findViewById(R.id.signup_password);
        phoneNumberField = findViewById(R.id.signup_phone_number);
        TextView signupRedirectText = findViewById(R.id.signupRedirectText);

        // Initialize DatabaseHelper for the sign-up database
        dbHelper = new DatabaseHelper(this, "UserDatabase.db");
        Toast.makeText(this, R.string.db_initialized, Toast.LENGTH_SHORT).show();

        // Set up click listeners
        signupRedirectText.setOnClickListener(v -> navigateToLoginScreen());

        Button signUpButton = findViewById(R.id.signup_button);
        signUpButton.setOnClickListener(v -> {
            String name = nameField.getText().toString();
            String username = usernameField.getText().toString();
            String password = passwordField.getText().toString();
            String phoneNumber = phoneNumberField.getText().toString();

            if (isInputValid(name, username, password, phoneNumber)) {
                if (isPasswordStrong(password)) {
                    signUpButton.setEnabled(false);

                    // Check for SMS permission
                    if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
                        ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, SMS_PERMISSION_CODE);
                    }

                    if (checkCustomPermission()) {
                        // Hash the user's password using bcrypt
                        String hashedPassword = BCrypt.hashpw(password, BCrypt.gensalt());

                        // Store the hashed password in the database
                        long result = dbHelper.addUser(username, hashedPassword);

                        if (result != -1) {
                            sendNotification();
                            if (isFirstLogin()) {
                                requestPhoneNumber();
                            } else {
                                navigateToLoginScreen();
                            }
                        } else {
                            showError(getString(R.string.error_create_user));
                        }
                    } else {
                        requestCustomPermission();
                    }
                    signUpButton.setEnabled(true);
                } else {
                    showError(getString(R.string.error_weak_password));
                }
            }
        });
    }

    private boolean isPasswordStrong(String password) {
        // Password strength validation logic
        // Check if the password contains at least 8 characters, including upper and lower case letters, numbers, and special characters.
        String passwordPattern = "^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[@$!%*?&])[A-Za-z\\d@$!%*?&]{8,}$";
        return Pattern.compile(passwordPattern).matcher(password).matches();
    }

    // Validate input fields
    private boolean isInputValid(String name, String username, String password, String phoneNumber) {
        if (TextUtils.isEmpty(name) || TextUtils.isEmpty(username) || TextUtils.isEmpty(password) || TextUtils.isEmpty(phoneNumber)) {
            showError(getString(R.string.error_required_fields));
            return false;
        }

        if (!isValidName(name)) {
            showError(getString(R.string.error_invalid_name));
            return false;
        }

        if (!isValidUsername(username)) {
            showError(getString(R.string.error_invalid_username));
            return false;
        }

        // Additional validation for the phone number
        if (!isValidPhoneNumber(phoneNumber)) {
            showError(getString(R.string.error_invalid_phone_number));
            return false;
        }

        return true;
    }

    // Phone Number validation
    private boolean isValidPhoneNumber(String phoneNumber) {
        // Phone number validation logic
        // Check if the phone number contains only digits and has a length of 10.
        return phoneNumber.matches("^[0-9]{10}$");
    }

    // Name validation
    private boolean isValidName(String name) {
        return name.matches("^[a-zA-Z ]+$");
    }

    // Username validation
    private boolean isValidUsername(String username) {
        return username.matches("^[a-zA-Z0-9_]+$");
    }

    // Display error message
    private void showError(String errorMessageText) {
        Toast.makeText(this, errorMessageText, Toast.LENGTH_SHORT).show();
    }

    // Check custom notification permission
    private boolean checkCustomPermission() {
        return ContextCompat.checkSelfPermission(this, "com.example.christine_emerson_weight_tracker_app.permission.POST_NOTIFICATIONS")
                == PackageManager.PERMISSION_GRANTED;
    }

    // Request custom notification permission
    private void requestCustomPermission() {
        if (ContextCompat.checkSelfPermission(this, "com.example.christine_emerson_weight_tracker_app.permission.POST_NOTIFICATIONS")
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{"com.example.christine_emerson_weight_tracker_app.permission.POST_NOTIFICATIONS"},
                    CUSTOM_PERMISSION_CODE);
        } else {
            sendNotification();
            if (isFirstLogin()) {
                requestPhoneNumber();
            } else {
                navigateToLoginScreen();
            }
        }
    }

    // Send a welcome notification if permission is granted for SMS
    private void sendNotification() {
        if (ContextCompat.checkSelfPermission(this, "com.example.christine_emerson_weight_tracker_app.permission.POST_NOTIFICATIONS")
                == PackageManager.PERMISSION_GRANTED) {

            NotificationCompat.Builder builder = new NotificationCompat.Builder(this, CHANNEL_ID)
                    .setSmallIcon(R.drawable.ic_alert)
                    .setContentTitle(getString(R.string.notification_welcome_title))
                    .setContentText(getString(R.string.notification_welcome_content))
                    .setPriority(NotificationCompat.PRIORITY_DEFAULT);

            NotificationManagerCompat notificationManager = NotificationManagerCompat.from(this);
            notificationManager.notify(NOTIFICATION_ID, builder.build());
        } else {
            showError(getString(R.string.error_custom_notification_permission));
        }
    }

    // Check if it's the user's first login
    private boolean isFirstLogin() {
        SharedPreferences preferences = getPreferences(Context.MODE_PRIVATE);
        return preferences.getBoolean(PREF_KEY_FIRST_LOGIN, true);
    }

    // Save the user's phone number
    private void saveUserPhoneNumber(String username, String phoneNumber) {
        long result = dbHelper.addUserPhoneNumber(username, phoneNumber);

        if (result != -1) {
            Toast.makeText(this, getString(R.string.phone_number_saved_successfully), Toast.LENGTH_SHORT).show();
        } else {
            showError(getString(R.string.error_failed_to_save_phone_number));
        }
    }

    // Request the user's phone number
    private void requestPhoneNumber() {
        String username = usernameField.getText().toString(); // Get the username
        String phoneNumber = phoneNumberField.getText().toString(); // Get the phone number

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(getString(R.string.dialog_title_phone_number));
        builder.setMessage(getString(R.string.dialog_message_phone_number));

        final EditText input = new EditText(this);
        input.setInputType(InputType.TYPE_CLASS_PHONE);
        input.setText(phoneNumber); // Pre-fill the phone number
        builder.setView(input);

        builder.setPositiveButton(getString(R.string.dialog_positive_button), (dialog, which) -> {
            String newPhoneNumber = input.getText().toString();
            Log.d("SignUpActivity", getString(R.string.log_phone_number, newPhoneNumber));
            Log.d("SignUpActivity", getString(R.string.log_saving_phone_number, newPhoneNumber, username));

            if (!TextUtils.isEmpty(newPhoneNumber)) {
                // Save the updated phone number to the database
                saveUserPhoneNumber(username, newPhoneNumber);

                // Send the welcome SMS with the updated phone number
                sendWelcomeSMS(newPhoneNumber);
            } else {
                // Save an empty phone number to the database
                saveUserPhoneNumber(username, "");

                // Navigate to the login screen
                navigateToLoginScreen();
            }
        });

        builder.setNegativeButton(getString(R.string.dialog_negative_button), (dialog, which) -> navigateToLoginScreen());

        AlertDialog dialog = builder.create();
        dialog.show();

        Button positiveButton = dialog.getButton(AlertDialog.BUTTON_POSITIVE);
        positiveButton.setTextColor(Color.BLACK);

        Button negativeButton = dialog.getButton(AlertDialog.BUTTON_NEGATIVE);
        negativeButton.setTextColor(Color.RED);
    }

    // Send a welcome SMS
    private void sendWelcomeSMS(String phoneNumber) {
        String message = getString(R.string.welcome_sms_message);
        sendSMS(phoneNumber, message);
    }

    // Send an SMS
    private void sendSMS(String phoneNumber, String message) {
        try {
            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(phoneNumber, null, message, null, null);
            Toast.makeText(this, getString(R.string.sms_sent_welcome), Toast.LENGTH_SHORT).show();
            navigateToLoginScreen(); // Navigate to the login screen if SMS is successfully sent.
        } catch (Exception e) {
            Toast.makeText(this, getString(R.string.sms_sending_failed, e.getMessage()), Toast.LENGTH_SHORT).show();
            Log.e("SMS_ERROR", getString(R.string.sms_sending_failed, e.getMessage()));
            showSmsSendingFailureDialog();
        }
    }

    // Show an SMS sending failure dialog
    private void showSmsSendingFailureDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(getString(R.string.dialog_title_sms_sending_failed));
        builder.setMessage(getString(R.string.dialog_message_sms_sending_failed));

        final EditText input = new EditText(this);
        input.setInputType(InputType.TYPE_CLASS_PHONE);
        builder.setView(input);

        builder.setPositiveButton(getString(R.string.dialog_positive_button_try_again), (dialog, which) -> {
            String phoneNumber = input.getText().toString();
            if (!TextUtils.isEmpty(phoneNumber)) {
                sendWelcomeSMS(phoneNumber);
            } else {
                showSmsSendingFailureDialog(); // Reopen the SMS failure dialog for re-entry.
            }
        });

        builder.setNegativeButton(getString(R.string.dialog_negative_button_skip), (dialog, which) -> navigateToLoginScreen());

        AlertDialog dialog = builder.create();
        dialog.show();

        Button positiveButton = dialog.getButton(AlertDialog.BUTTON_POSITIVE);
        positiveButton.setTextColor(Color.BLACK);

        Button negativeButton = dialog.getButton(AlertDialog.BUTTON_NEGATIVE);
        negativeButton.setTextColor(Color.RED);
    }

    // Navigate to the login screen
    private void navigateToLoginScreen() {
        Intent intent = new Intent(SignUpActivity.this, LoginActivity.class);
        startActivity(intent);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
    }
}