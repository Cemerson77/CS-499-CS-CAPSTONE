package com.example.christine_emerson_weight_tracker_app;

/**
 * The `WeightEntry` class is a part of the FitTrack Android application project.
 * Represents a weight entry with associated date, weight, and a flag indicating whether the
 * weight is in kilograms.
 *
 * Project: FitTrack Android Application
 * Author: Christine Emerson
 * License: No license (proprietary)
 */
public class WeightEntry {
    // Properties of a weight entry
    private String date;        // Date of the weight entry
    private double weight;      // Weight value
    private boolean isKgUnit;   // Flag indicating whether the weight is in kilograms

    /**
     * Constructs a `WeightEntry` with the specified date, weight, and unit information.
     *
     * @param date     The date of the weight entry.
     * @param weight   The weight value.
     * @param isKgUnit Indicates whether the weight is in kilograms.
     */
    public WeightEntry(String date, double weight, boolean isKgUnit) {
        this.date = date;
        this.weight = weight;
        this.isKgUnit = isKgUnit;
    }

    /**
     * Gets the date of the weight entry.
     *
     * @return The date of the weight entry.
     */
    public String getDate() {
        return date;
    }

    /**
     * Sets the date of the weight entry.
     *
     * @param date The new date value.
     */
    public void setDate(String date) {
        this.date = date;
    }

    /**
     * Gets the weight value.
     *
     * @return The weight value.
     */
    public double getWeight() {
        return weight;
    }

    /**
     * Sets the weight value and unit information.
     *
     * @param weight   The new weight value.
     * @param isKgUnit Indicates whether the weight is in kilograms.
     */
    public void setWeight(double weight, boolean isKgUnit) {
        this.weight = weight;
        this.isKgUnit = isKgUnit;
    }

    /**
     * Checks if the weight is in kilograms.
     *
     * @return `true` if the weight is in kilograms, `false` otherwise.
     */
    public boolean isKgUnit() {
        return isKgUnit;
    }

    /**
     * Sets the unit information for the weight.
     *
     * @param isKgUnit Indicates whether the weight is in kilograms.
     */
    public void setIsKgUnit(boolean isKgUnit) {
        this.isKgUnit = isKgUnit;
    }
}
